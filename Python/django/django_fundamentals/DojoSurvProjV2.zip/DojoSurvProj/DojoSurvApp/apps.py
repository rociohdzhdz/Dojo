from django.apps import AppConfig


class DojosurvappConfig(AppConfig):
    name = 'DojoSurvApp'
