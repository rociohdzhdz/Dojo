from django.shortcuts import render, HttpResponse, redirect
# Create your views here.

def index(request):
    return render (request, 'index.html')

def create(request):
    print("New Survey")
    print(request.POST)
    print(request.POST['survname'])
    print(request.POST['DojoLoc'])
    print(request.POST['FavLang'])
    print(request.POST['SurvComms'])
    request.session['surveynombre']=request.POST['survname']
    request.session['surveylugar']=request.POST['DojoLoc']
    request.session['surveylenguaje']=request.POST['FavLang']
    request.session['surveycommentarios']=request.POST['SurvComms']
    return render(request, 'result.html')
