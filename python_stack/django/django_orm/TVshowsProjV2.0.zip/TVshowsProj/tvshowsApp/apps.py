from django.apps import AppConfig


class TvshowsappConfig(AppConfig):
    name = 'tvshowsApp'
