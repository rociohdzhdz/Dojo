from django.apps import AppConfig


class AmadonappConfig(AppConfig):
    name = 'Amadonapp'
