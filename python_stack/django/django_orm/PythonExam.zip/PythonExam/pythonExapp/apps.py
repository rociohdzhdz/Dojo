from django.apps import AppConfig


class PythonexappConfig(AppConfig):
    name = 'pythonExapp'
